function productRating(rating) {
    switch(rating) {
        case 1: return "Poor";
        case 2: return "Average";
        case 3: return "Good";
        default: return "Invalid rating";
    }
}

console.log(productRating(2)); // Output: Average