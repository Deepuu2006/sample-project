console.log("check a number is positive ,negative or zero")
let n=5
if(n>0){
    console.log("number is positive")
}
else if(n<0){
    console.log("number is negative")
}
else{
    console.log("number is zero")
}