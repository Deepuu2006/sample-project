console.log("check student is pass or fail")
let marks=45
if(marks>50){
    console.log("pass");
}
else{
    console.log("fail");
}