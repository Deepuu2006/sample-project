console.log("assign studemt grades")
let marks=45
if(marks>=90&&marks<=100){
    grade="A";
}else if(marks>=75){
    grade="B";
}
else if(marks>=60){
    grade="C";
}
else if (marks>=50){
    grade="D";
}
else{
    grade="F";
}
console.log("marks:"+marks);
console.log("grade:"+grade);